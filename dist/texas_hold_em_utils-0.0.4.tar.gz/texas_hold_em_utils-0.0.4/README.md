# texas-hold-em
A package containing the logic for a Texas Hold 'Em game, along with some related utilities.