# texas-hold-em

A package containing the logic for a Texas Hold 'Em game, along with some related utilities.

[Docs](https://github.com/amarkules1/texas-hold-em/blob/main/texas_hold_em_utils/texas_hold_em_utils.md)